let xhr;
let endPoint="http://worldtimeapi.org/api/timezone/Asia/Kolkata";

function connect(){
    xhr = new XMLHttpRequest();
    xhr.onreadystatechange=processresponse;
    xhr.open("GET",endPoint,true);
    xhr.send(null);
}

function processresponse(){
    if(xhr.readyState===4 && xhr.status===200){
        let str=xhr.responseText;
        //console.log(str.datetime);
        let obj=JSON.parse(str);
        // console.log(obj.datetime);
        let today = new Date(obj.datetime);
        console.log(today.toDateString());
        console.log(today.toLocaleString());

        let span = document.getElementById("curDateTime");

        span.innerHTML=today.toDateString()+" , "+today.toLocaleTimeString();

    } else if(xhr.readyState===4 && xhr.status!==200){
        alert("Sorry request cannot be fullfilled reason : "+xhr.statusText);
    }
}