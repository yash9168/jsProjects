let xhr;
let endPoint =
  "http://127.0.0.1:5500/Ajax Examples/example3/person_details.txt";
function connect() {
  xhr = new XMLHttpRequest();
  xhr.onreadystatechange = processresponse;
  xhr.open("GET", endPoint, true);
  xhr.send(null);
}
function processresponse() {
  if (xhr.readyState === 4 && xhr.status === 200) {
    let personDiv = document.getElementById("person");
    let jsonResponse = xhr.responseText;
    const obj = JSON.parse(jsonResponse);
    personDiv.innerHTML =
      "<span>Name: </span>" + obj.name + "<br><span>Age: </span>" + obj.age;

    let projectArr = obj.projects;
    let str = "";
    // for (let p of projectArr) {
    //   str += p.name + ",";
    // }
    projectArr.forEach((p) => {
      str += p.name + ",";
    });
    str = str.substring(0, str.lastIndexOf(","));
    personDiv.innerHTML += "<br><span>Projects: </span>" + str;
  }
}
